USD FX Quant Signal Engine V2 — iPhone PWA
1. Upload the CONTENTS of this folder to Netlify Drop (not the ZIP itself).
2. Open the resulting HTTPS netlify.app address in Safari.
3. Add to Home Screen.
4. Open the new icon; it runs as a standalone iPhone app.
5. Enter your Twelve Data API key in Settings and scan.
